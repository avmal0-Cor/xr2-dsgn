LayoutTools2011 INSTALLATION

----------------------------------------------------------------------------------------------------------------------------


Quick Windows Install:  

	1. First close Maya. 
	2. Then simply unzip the Maya_LayoutTools2011_Install.zip file directly into your -> MyDocuments/maya/2011 folder (2011-x64 for 64bit).
	   (note: For older versions of Maya use the equivelent folder)  
	3. Restart Maya.
	4. Run LayoutTools by clicking on the LT button from the newly installed LayoutTools shelf.  
	5. This will open the LayoutTools interface as a floating window.  
	6. After LayoutTools 3.5 is started the first time, hotkeys will be created for quickly opening the LayoutTools UI.
	7. "L" opens LayoutTools as a floating UI.  "l" toggles LayoutTools in the Channel Box.

 
----------------------------------------------------------------------------------------------------------------------------


Mac Install:

	1.  Close Maya and Unzip Maya_LayoutTools2011_Install.zip to a temporary location

	2.  Put the LT scripts...

                        LT_displayProcs.mel
                        LT_generalProcs.mel
                        LT_layoutProcs.mel
			LT_placementProcs.mel
			LT_assemblyProcs.mel
                        LT_optionVars.mel      
                        LT_UI.mel

		...into your -> /Users/<UserName>/Library/Preferences/Autodesk/maya/2011/scripts folder (or earlier version)  

	3.  Put the LT_docs folder in -> /Users/<UserName>/Library/Preferences/Autodesk/maya/2011

	4.  Put the LT icon files in -> /Users/<UserName>/Library/Preferences/Autodesk/maya/2011/prefs/icons

	5.  Put the shelf_LayoutTools.mel shelf file in -> /Users/<UserName>/Library/Preferences/Autodesk/maya/2011/prefs/shelves

	6.  Put the LT_ExampleProject anywhere and just point to it from within the LayoutTools UI.

	7.  Restart Maya and Run LayoutTools by clicking on the LT button from the newly installed LayoutTools shelf.


----------------------------------------------------------------------------------------------------------------------------


Windows Manual Install:

	1.  Close Maya and Unzip Maya_LayoutTools2011_Install.zip to a temporary location

	2.  Put the LT scripts...

                        LT_displayProcs.mel
                        LT_generalProcs.mel
                        LT_layoutProcs.mel
			LT_placementProcs.mel
			LT_assemblyProcs.mel
                        LT_optionVars.mel      
                        LT_UI.mel

		...into your -> MyDocuments/maya/2011 folder (2011-x64 for 64bit).  

	3.  Put the LT_docs folder in -> MyDocuments/maya/2011

	4.  Put the LT icon files in -> MyDocuments/maya/2011/prefs/icons

	5.  Put the shelf_LayoutTools.mel shelf file in -> MyDocuments/maya/2011/prefs/shelves

	6.  Put the LT_ExampleProject anywhere and just point to it from within the LayoutTools UI.

	7.  Restart Maya and Run LayoutTools by clicking on the LT button from the newly installed LayoutTools shelf.


----------------------------------------------------------------------------------------------------------------------------


LT_ExampleProject 


LT_ExampleProject is an example of how you would setup a simple project structure to work with LayoutTools.  
For this example, set your current project in Maya to the folder LT_Project.  Open LayoutTools and check the import tab.  
If the icons are not already loaded, reset the LayoutTools settings (Edit->ResetSettings).  
You should now see icons for all of the maya files contained within the example project in the LayoutTools Import tab.  



